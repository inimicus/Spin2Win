-- -----------------------------------------------------------------------------
-- Spin2Win
-- Author:  g4rr3t
-- Created: Aug 22, 2018
--
-- Defaults.lua
-- -----------------------------------------------------------------------------

local defaults = {
    debugMode = 0,
    positionLeft = 100,
    positionTop  = 100,
    unlocked = true,
}

function S2W:GetDefaults()
    return defaults
end
